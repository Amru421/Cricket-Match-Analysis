# 🏏 Cricket Data Analysis

A beginner-friendly cricket analytics project using Python, Pandas, Matplotlib and Seaborn. It explores batting, bowling, team results and player performance using a small **illustrative sample dataset** included in this repository.

## Features
- Batting runs, averages and strike rates
- Bowling wickets, economy and bowling averages
- Team wins and match results
- Player comparisons and visualizations
- CSV outputs for further analysis

## Project structure
```text
Cricket-Data-Analysis/
├── dataset/
│   ├── matches.csv
│   ├── batting.csv
│   └── bowling.csv
├── notebooks/
│   └── cricket_analysis.ipynb
├── visualizations/
│   └── (generated charts are saved here)
├── src/
│   └── analyze_cricket.py
├── requirements.txt
└── README.md
```

## Setup
1. Install Python 3.9 or newer.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the analysis:
   ```bash
   python src/analyze_cricket.py
   ```
5. Find summary CSV files in `outputs/` and charts in `visualizations/`.

## Open the notebook
```bash
pip install jupyter
jupyter notebook
```
Open `notebooks/cricket_analysis.ipynb`.

## Dataset note
The included CSV files contain **fictional sample data for demonstrating the analysis workflow**. They are not official match records. Replace them with a properly licensed real dataset before making claims about actual players, teams or matches. Keep the same column names when replacing the files.

## Metrics
- Batting average = total runs / dismissals
- Strike rate = runs / balls faced × 100
- Bowling average = runs conceded / wickets
- Economy rate = runs conceded / overs bowled

For this demonstration, each batting row represents one player's aggregate performance in one match, and each bowling row represents one bowler's aggregate performance in one match.

## Future improvements
- Import ball-by-ball datasets
- Add Power BI dashboard
- Add match outcome prediction
- Add player performance trends across seasons

## Author
Varsha

## License
Educational use. Check the license and terms of any replacement dataset before redistribution.
